function traiect_imp = impartire_traiectorie(traiect,d)

    for i=2:size(traiect,2)
       
        A=traiect(:,i-1)';
        B=traiect(:,i)';
        dist=pdist2(A,B);

        pas=round(dist/(d/3));

        x=linspace(A(1),B(1),pas);
        y=linspace(A(2),B(2),pas);

         %for j=1:size(x,2)
             %plot(x(j),y(j),'o--');
        % end

        if i==2
            traiect_imp=[x(1:end-1);y(1:end-1)];
        else
            traiect_imp=[traiect_imp [x(1:end-1);y(1:end-1)]];
        end
    end
    traiect_imp=[traiect_imp traiect(:,end)];

end