function [drona] = rotatie(drona,teta)

    R=[cos(teta),-sin(teta);sin(teta) cos(teta)];

    drona{2}=drona{2}-drona{1}';
    drona{2}=R*drona{2};
    drona{2}=drona{2}+drona{1}';

    drona{3}=drona{3}-drona{1}';
    drona{3}=R*drona{3};
    drona{3}=drona{3}+drona{1}';

end