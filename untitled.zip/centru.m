function mini= centru(x,y,cx,cy)
    mini=pdist2([x(1) y(1)],[cx cy]);
    %plot(cx,cy,'o--');
    for i=1:size(x,1)
        %plot([x(i); cx], [y(i); cy]);
        p1=[x(i),y(i)];
        p2=[cx,cy];
        distanta=pdist2(p1,p2);
            if distanta<mini
                mini=distanta;
            end
    end
end