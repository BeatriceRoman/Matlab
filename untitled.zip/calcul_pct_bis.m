function pct = calcul_pct_bis(a,b,c,dist)
    
    vect_ba=a-b;
    vect_bc=c-b;
    lung_ba=norm(vect_ba);
    lung_bc=norm(vect_bc);
    norm_ba=vect_ba/lung_ba;
    norm_bc=vect_bc/lung_bc;
    bisect=norm_ba+norm_bc;
    teta=calcul_unghi(a,b,c);
    norm_bisect=sign(teta)*bisect/(norm(bisect));
    
    teta=rad2deg(teta);
    
    if teta<0
        dist=dist/sind((360+teta-180)/2);
    else
        dist=dist/cosd(teta/2);
    end
    pct=b+norm_bisect*dist;
end