function arie = calcul_arie_parcursa(x,y,d)
    n=size(x,2);
    arie=0;
    for i=1:n
        if i~=n
            a=[x(i),y(i)];
            b=[x(i+1),y(i+1)];
            dist=pdist2(a,b)*d;
        else
            a=[x(i),y(i)];
            b=[x(1),y(1)];
            dist=pdist2(a,b)*d;
        end
    arie=arie+dist;
    end

end