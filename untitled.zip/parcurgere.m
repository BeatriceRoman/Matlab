function [timp] = parcurgere(drona,traiect,d,v)
    
    t=(d/2)/v;
     tic   
    for i=1:size(traiect,2)
        
        drona{1,1}=[traiect(1,i),traiect(2,i)];
        
        
        if i==1
            A=[traiect(1,i)-d,traiect(2,i)];
            B=drona{1,1};
            C=[traiect(1,i+1),traiect(2,i+1)];
        elseif i==size(traiect,2)
            A=[traiect(1,i-1),traiect(2,i-1)];
            B=drona{1,1};
        else
            A=[traiect(1,i-1),traiect(2,i-1)];
            B=drona{1,1};
            C=[traiect(1,i+1),traiect(2,i+1)];
        end

        dx=B(1)-A(1);
        dy=B(2)-A(2);

        drona{2}(1,:)=drona{2}(1,:)+dx;
        drona{2}(2,:)=drona{2}(2,:)+dy;

        drona{3}(1,:)=drona{3}(1,:)+dx;
        drona{3}(2,:)=drona{3}(2,:)+dy;

        if i~=size(traiect,2)
        teta=real(calcul_unghi(A,B,C)); 
            if teta~=0
                teta1=0;
                pas_rotatie=3;;
                for j=1:pas_rotatie

                drona=rotatie(drona,teta1);
                pause(0.3);
                plot(drona{2}(1,:),drona{2}(2,:),'Color','blue');
                plot(drona{1}(1),drona{1}(2),'o--','Color','r');
                plot(drona{3}(1,:),drona{3}(2,:),'Color','r','LineWidth',2);

                teta1=teta1+teta/pas_rotatie;

                end
            end
        end

        plot(drona{2}(1,:),drona{2}(2,:),'Color','blue');
        plot(drona{1}(1),drona{1}(2),'o--','Color','r');
        plot(drona{3}(1,:),drona{3}(2,:),'Color','r','LineWidth',2);

        pause(t);
    end
    timp=toc;
end