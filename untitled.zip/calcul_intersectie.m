function [xinters yinters] = calcul_intersectie(A,B,C,D)
 
        dx1=B(1)-A(1);
        dy1=B(2)-A(2);
        dx2=D(1)-C(1);
        dy2=D(2)-C(2);
        a1=[dx1, -dx2;dy1, -dy2];
        b1=[-C(1)+A(1);-C(2)+A(2)];
        det_t1 = (C(1) - A(1)) * dy2 - (C(2) - A(2)) * dx2;
        det_t2 = (C(1) - A(1)) * dy1 - (C(2) - A(2)) * dx1;
        det1 = dx1 * dy2 - dy1 * dx2;
        
        
        t1 = det_t1 / det1;
        t2 = det_t2 / det1;
        xinters = A(1) + t1 * dx1;
        yinters = A(2) + t1 * dy1;
        
end