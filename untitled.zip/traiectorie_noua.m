function [traiect] = traiectorie_noua(x,y,d)
    
    arie_totala=polyarea(x',y');
    arie_partiala=0;

    cerc_vechi=[x';y'];
    k=1;%nr de loopuri

    while arie_totala-d*d>arie_partiala && size(cerc_vechi,2)>2
        q=0; %nr de puncte din cercul curent

        n=size(cerc_vechi,2);
        for i=1:n
            b=cerc_vechi(:,i)';

            if i==1 && k<=2
                a=cerc_vechi(:,end)';
                c=cerc_vechi(:,i+1)'; %pt primele 2 loopuri nu trebuie luat in considerare punctul in care se intalnesc loopurile
            elseif i==1 && k>2
                a=cerc_vechi(:,end-1)';
                c=cerc_vechi(:,i+1)';
            elseif i==n && k<=2
                a=cerc_vechi(:,i-1)';
                c=cerc_vechi(:,1)';
            elseif i==n && k>2
                a=cerc_vechi(:,end-1)';
                c=cerc_nou(:,1)';
            else
                a=cerc_vechi(:,i-1)';
                c=cerc_vechi(:,i+1)';
            end

        P=calcul_pct_bis(a,b,c,d);
        
        if i==1
            q=q+1;
            cerc_nou=P';
            plot(cerc_nou(1,q),cerc_nou(2,q),'o--');
        else
            punct_anterior=cerc_nou(:,q)';                 % daca doua puncte consecutive sunt prea apropiate se face media dintre cele doua
            dist=pdist2(punct_anterior,P);
            if dist<=d/4*3
                cerc_nou(:,q)=mean([punct_anterior;P])';
            else
                q=q+1;
                cerc_nou(1,q)=P(1);
                cerc_nou(2,q)=P(2);
                plot(cerc_nou(1,q),cerc_nou(2,q),'o--');
            end

        end

        
        
        end

        
        if k==1

            d=d*2;
            traiect=cerc_nou;

        elseif k==2

            A=cerc_vechi(:,1)';
            B=cerc_vechi(:,end)';
            C=cerc_nou(:,1)';
            D=cerc_nou(:,2)';

            [ptx pty]=calcul_intersectie(A,B,C,D); %doar pentru al doilea loop se calculeaza punctul de intersectie
                                                   %se adauga la traiectorie si se face bisectoare         
            colt=[ptx; pty];
            plot(colt(1,1),colt(2,1),'o--');  

            plot([cerc_vechi(1,end) colt(1,1) cerc_nou(1,1)] , [cerc_vechi(2,end) colt(2,1) cerc_nou(2,1)])

            cerc_vechi=[cerc_vechi colt];
            traiect=[traiect colt]; %se adauga coltul calculat la traiectorie 
            coltn=calcul_pct_bis(cerc_vechi(:,end-1)', colt',cerc_nou(:,1)' ,d); %se calculeaza coltul pt loop ul 2
           
            cerc_nou=[cerc_nou coltn'];%se adauga la traiectorie 
             traiect=[traiect cerc_nou];
            plot(coltn(1,1),coltn(1,2),'o--');
            
            
        else
            traiect=[traiect cerc_nou];
            plot([cerc_nou(1,1) cerc_vechi(1,end)],[cerc_nou(2,1) cerc_vechi(2,end)]);
        end
        
        
        plot(cerc_nou(1,:),cerc_nou(2,:));
        
        arie_partiala=arie_partiala+calcul_arie_parcursa(cerc_nou(1,:),cerc_nou(2,:),d);
        cerc_vechi=cerc_nou;
        k=k+1

    end
end