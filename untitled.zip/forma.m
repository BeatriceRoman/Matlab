function [x,y] = forma
    t=figure('Name','Traiectorie')
    xlabel('ox-cm');
    ylabel('oy-cm');
    xlim([0,300])
    ylim([0,300])
    grid on
    %axis equal
    [x,y]=getpts(t)
    %x=[50 100 150 150 50]';
    %y=[100 50 50 200 200]';
    plot([x(:); x(1)],[y(:); y(1)],'LineWidth',2,'Color','g');
    axis equal;
    hold on
end