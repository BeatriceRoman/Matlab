function teta = calcul_unghi(a,b,c)
    v1=b-a;
    v2=c-b;
    produs_scalar=dot(v1,v2);
    semn=sign(det([v1;v2]));
    teta=semn*acos(produs_scalar/(norm(v1)*norm(v2)));
end